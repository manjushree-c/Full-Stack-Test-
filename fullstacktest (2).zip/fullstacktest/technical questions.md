How long did you spend on the coding test? What would you add to your solution if you had more time? If you didn't spend much time on the coding test then use this as an opportunity to explain what you would add.
=>I have spent 3 and half day on coding test. 1 and half day for CRUD operations(CRUD for tab and data) and tabs and data are dynamic. and 1 and half day for checking,analysis of design, what exactly do, planning,DB creation, designing page for web view and then mobile view etc. If i had more time this task will be more optimize and structure, all code will commented for future reference, image optimization and responsiveness. Client and server validation. media query for various devices etc.




How would you track down a performance issue in production? Have you ever had to do this?
=> Image responsiveness, Optimization, validation while entering records, Only for specific devices.


Please describe yourself using JSON.
=>
{"personalinfo":[  
    {"name":"Manjushree", 
    "lastname":"Chabukswar",
    "nationality":"Indian",
    "state":"Maharashtra",
    "City" :"Pune",
}],
 "education":[  
    {"highestqualification":"Msc Computer Science", 
    "college":"Nowrosjee Wadia college",
    "university":"Pune University",
    "yearofpassing":"2017",
   
}],

"experience":[  
    {"experience":"3.3years", 
    "technology":"PHP",
    "framework":"Codeigniter",
    "scriptinglanguage":"JS",
   "databasehandel" :"MYSQL",
   "api":"restful API"
}],
    "paymentgatwayintegrated":[  
    {"p1":"EaseBuzz", 
    "p2":"PayUMoney",
    "p3":"CCAvenue",
    "p4":"CCAvenue with HDFC",
    "p5" :"Authorize.net",
    "p6":"Braintree",
    "p7":"RazorPay",
    
}],
"smsgatewayintegration":"SMSGATEWAYHUB",
},

"previouscompanycompletedprojects":[  
    {"u1":"http://kemhospitalpune.org/", 
    "u2":"https://esbee-electrotech.com/",
    "u3":"https://www.intradaysecrets.com/",
    "u4":"http://www.vbev.co.in/",
    "u5" :"https://crescohr.com/",
    "u6":"https://samarthquickpro.com/",
    "u7":"http://mandkehearing.com/",
     "u8":"https://www.sitfitinc.com/",
    "u9":"https://braingita.com/",
    "u10":"https://cleanjoypune.com/",

}],
"contactinfo":[{
	"emailId":"Chabukswarmanjushree18@gmail.com",
	"contactnumber" :"9657641557",
}]

  }