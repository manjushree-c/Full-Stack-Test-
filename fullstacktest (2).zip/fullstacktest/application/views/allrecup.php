<!DOCTYPE html>
<html lang="en">
<head>

	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
    <meta name="keywords" content="" />
 
    <meta name="description" content="" />


    <!-- PAGE TITLE HERE -->
   
    
    <title>Update Tab Records</title>
        
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <?php include('common-css.php');?>

    
</head>

<body>

	<div class="page-wraper"> 
       	
      
        
        <!-- CONTENT START -->
       
<div class="container"><h1><a href="<?php echo base_url()?>index">Home</a> </h1></div>


<hr></hr>
      
        
<div class="container"><h2>Update Record</h2></div>


 <div class="wt-box">
                        <div class="bg-white block-shadow radius-md  p-a30">
                            <form  method="POST" action="<?php echo base_url()?>updatetabrec">
                        <input type="hidden" name="tbl_tabdetails_id" value="<?php echo $tabrecup[0]['tbl_tabdetails_id'];?>" >
                             <input type="hidden" name="tbl_tab_id" value="<?php echo $tabrecup[0]['tbl_tab_id'];?>" >

                            <div class="row">
                                <div class="col-md-4">
                                    <label>Tab Name:<font color="red">*</font></label>
                                </div>
                               <div class="col-md-6">
                                    <div class="form-group">
                                        <input name="tab_name" type="text" required class="form-control bg-gray bdr-none" value="<?php echo $tabrecup[0]['tab_name'];?>" readonly>
                                    </div>
                                </div>

                                 
                                 <div class="col-md-4">
                                    <label>Tab Description:<font color="red">*</font></label>
                                </div>
                                 <div class="col-md-6">
                                     <div class="form-group">
                      <textarea name="tabdetails_desc" rows="2" cols="50"  class="form-control bg-gray bdr-none">
                            <?php echo $tabrecup[0]['tabdetails_desc'];?>
                          </textarea>

                         </div>
                     </div>

                        <div class="col-md-4">
                                    <label>Tab Image:<font color="red">*</font></label>
                                </div>
                                 <div class="col-md-6">
                                     <div class="form-group">
                                <input type="file" name="tabdetails_image"  value="<?php echo $tabrecup[0]['tabdetails_image'];?>" >
                                <input type="hidden" name="tabdetails_image1"  value="<?php echo $tabrecup[0]['tabdetails_image'];?>">
                                     <img src="<?php echo base_url()?>upload/<?php echo $tabrecup[0]['tabdetails_image'];?>" style="width: 200px;height: auto;margin: 10px" name="tabdetails_image" >
                         </div>
                     </div>


                                 

                                 

                                <div class="col-md-12 text-right">
                                    <button name="submit" type="submit" value="Submit" class="site-button  m-r15">Submit</button>
                                  
                                </div>

                            </div>

                        </form>
                        </div>
                    </div>

<hr></hr>





<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
        
    
 	</div>



</body>
 
<?php include('common-js.php');?>

</html>
