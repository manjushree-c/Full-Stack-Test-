<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Full Stack Test</title>
<!-- <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/3.3.7/darkly/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/slider.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/js/accordion.js"></script>
 </head>


<body>

  <div class="container">

    <div class="col-md-12">
    
    <h1 style="text-align: center;margin: 2%">Full Stack Test : <a href="<?php echo base_url()?>tabdata" style=" color: #33ccff;text-decoration: none;">CRUD Operations</a></h1>
<!-- Bootstrap Tabs -->
  <ul id="tabs" class="nav" style="float: left;">

    <?php
$z=1;
     if(isset($getallrecords) && !empty($getallrecords)){
            foreach($getallrecords as $getallrecords)
{      ?>
    <li class="<?php if($z==1){?>active<?php }?>"><a data-toggle="tab" href="#t<?php echo $getallrecords['tbl_tab_id'];?>" class="text"><?php echo $getallrecords['tab_name'];?></a></li>

  <?php 
$z++;
}

}?>
   
  </ul>
  <div class="tab-content">

   
     <?php 
     $a=1;
     if(isset($getallrecord) && !empty($getallrecord)){
            foreach($getallrecord as $getrec)
{    


 ?>
 
    
    <div id="t<?php echo $getrec['tbl_tab_id'];?>" class="tab-pane fade in <?php if($a==1){?>active<?php }?> col-md-10" >
     
        <?php 

        $id=$getrec['tbl_tab_id'];
        $CI=&get_instance();
        $CI->load->model('HomeModel');
        $result=$CI->HomeModel->allrecords($id);
          $res=$CI->HomeModel->allrecords($id);

      
        ?>

      <div id="carousel-demo<?php echo $id?>" class="carousel slide" data-interval="3000" data-ride="carousel" >
 <!-- Indicators -->
        <ol class="carousel-indicators">
        <?php 

    
       $total = count($res);
            $number = 0;
 foreach($res as $res){

        ?>
        <?php if($number==0){?>

        <li data-target="#carousel-demo<?php echo $res['tbl_tab_id']?>" data-slide-to="<?php echo $number; ?>" class="active"></li>
       <?php }else {?>
         <li data-target="#carousel-demo<?php echo $res['tbl_tab_id']?>" data-slide-to="<?php echo $number; ?>" ></li>
<?php } $number++;}?>
        </ol>
  
  <!-- Sliding images statring here --> 
          <div class="carousel-inner"> 
            <?php 

  
        //print_r($result);
        $j=0;
  if(isset($result) && !empty($result)){
   foreach($result as $allrecords){ 
  ?>
          <div class="item <?php if($j==0){?>active<?php }?>"> 
         <div class="col-md-6 ">
          <div class="carousel-caption"  >
          <p><?php echo $allrecords['tabdetails_desc'];?></p>
          
          </div>
          </div>
          <div class="col-md-6">
          <img src="<?php echo base_url()?>upload/<?php echo $allrecords['tabdetails_image'];?>" alt="<?php echo $allrecords['tabdetails_image'];?>"  class="img-fluid">   
          </div> 


          </div>

<?php $j++;}}?>
      


          </div> 



             </div>



                </div>
<?php $a++; } }?>


    
  </div>
  
<!-- /Bootstrap Tabs -->
<!-- Bootstrap Accordion -->
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"></div>
<!-- /Bootstrap Accordion -->

  </div>



<script type="text/javascript">
$(document).ready(function(){
getAccordion("#tabs",768);
});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>



</body>
</html>
