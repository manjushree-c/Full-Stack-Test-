-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2021 at 02:41 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fullstacktest`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tab`
--

CREATE TABLE `tbl_tab` (
  `tbl_tab_id` int(11) NOT NULL,
  `tab_name` varchar(255) NOT NULL,
  `tabDateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_tab`
--

INSERT INTO `tbl_tab` (`tbl_tab_id`, `tab_name`, `tabDateCreated`) VALUES
(1, 'Education', '2021-08-10 09:11:16'),
(2, 'Technology', '2021-08-10 09:11:24'),
(3, 'Communication', '2021-08-10 12:31:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tabdetails`
--

CREATE TABLE `tbl_tabdetails` (
  `tbl_tabdetails_id` int(11) NOT NULL,
  `tbl_tab_id` int(11) NOT NULL,
  `tabdetails_desc` text NOT NULL,
  `tabdetails_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_tabdetails`
--

INSERT INTO `tbl_tabdetails` (`tbl_tabdetails_id`, `tbl_tab_id`, `tabdetails_desc`, `tabdetails_image`) VALUES
(1, 1, ' Education is the most powerful weapon which you can use to change the world.\r\n\r\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ', 'DL-Communication.jpg'),
(2, 1, 'You are always a student, never a master. You have to keep moving forward.\r\n                          ', 'rptgtpxd-1396254731.jpg'),
(3, 2, ' Technology is best when it brings people together.\r\n                                                    ', 'DL-Technology.jpg'),
(4, 2, ' Let’s go invent tomorrow instead of worrying about what happened yesterday.\r\n                                                    ', 'DL-Communication.jpg'),
(5, 3, 'The most important thing in communication is to hear what isn’t being said.\r\n                                                    ', 'DL-Communication.jpg'),
(6, 3, ' Communication works for those who work at it.\r\n                                                                              ', 'DL-Learning-1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_tab`
--
ALTER TABLE `tbl_tab`
  ADD PRIMARY KEY (`tbl_tab_id`);

--
-- Indexes for table `tbl_tabdetails`
--
ALTER TABLE `tbl_tabdetails`
  ADD PRIMARY KEY (`tbl_tabdetails_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_tab`
--
ALTER TABLE `tbl_tab`
  MODIFY `tbl_tab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_tabdetails`
--
ALTER TABLE `tbl_tabdetails`
  MODIFY `tbl_tabdetails_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
